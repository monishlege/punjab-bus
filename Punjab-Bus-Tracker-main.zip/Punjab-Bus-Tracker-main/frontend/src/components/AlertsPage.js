import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AlertsPage = () => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // all, unread, read
  const [alertType, setAlertType] = useState('all'); // all, arrival, delay, emergency, service

  useEffect(() => {
    fetchAlerts();
    generateSampleAlerts();
  }, []);

  const fetchAlerts = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const headers = { Authorization: `Bearer ${token}` };
      
      const response = await axios.get(`${API}/alerts`, { headers });
      setAlerts(response.data);
    } catch (error) {
      console.error('Error fetching alerts:', error);
      toast.error('Failed to load alerts');
    } finally {
      setLoading(false);
    }
  };

  const generateSampleAlerts = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const headers = { Authorization: `Bearer ${token}` };

      const sampleAlerts = [
        {
          alert_type: 'arrival',
          title: 'Bus Arriving Soon',
          message: 'CHD-LDH Express will arrive at Mohali in 5 minutes',
          route_id: null,
          bus_number: 'PB-12-3456'
        },
        {
          alert_type: 'delay',
          title: 'Service Delay',
          message: 'ASR-JLR Route is running 15 minutes late due to traffic',
          route_id: null,
          bus_number: 'PB-34-7890'
        },
        {
          alert_type: 'emergency',
          title: 'Emergency Alert',
          message: 'Emergency services required at Ludhiana bus stand',
          route_id: null,
          bus_number: null
        },
        {
          alert_type: 'service',
          title: 'Service Update',
          message: 'New route CHD-BTI now available with premium seating',
          route_id: null,
          bus_number: null
        }
      ];

      // Check if we already have alerts
      if (alerts.length === 0) {
        for (const alertData of sampleAlerts) {
          const queryParams = new URLSearchParams({
            alert_type: alertData.alert_type,
            title: alertData.title,
            message: alertData.message,
            ...(alertData.route_id && { route_id: alertData.route_id }),
            ...(alertData.bus_number && { bus_number: alertData.bus_number })
          });
          await axios.post(`${API}/alerts?${queryParams}`, {}, { headers });
        }
        // Refresh alerts after creating samples
        setTimeout(fetchAlerts, 1000);
      }
    } catch (error) {
      console.error('Error generating sample alerts:', error);
    }
  };

  const markAsRead = async (alertId) => {
    try {
      const token = localStorage.getItem('auth_token');
      const headers = { Authorization: `Bearer ${token}` };
      
      await axios.patch(`${API}/alerts/${alertId}/read`, {}, { headers });
      
      // Update local state
      setAlerts(alerts.map(alert => 
        alert.id === alertId ? { ...alert, is_read: true } : alert
      ));
      
      toast.success('Alert marked as read');
    } catch (error) {
      toast.error('Failed to mark alert as read');
    }
  };

  const getAlertIcon = (type) => {
    switch (type) {
      case 'arrival':
        return (
          <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
      case 'delay':
        return (
          <svg className="w-5 h-5 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.464 0L4.34 16.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
        );
      case 'emergency':
        return (
          <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.464 0L4.34 16.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
        );
      case 'service':
        return (
          <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
      default:
        return (
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5 5-5-5h5v-5a7.5 7.5 0 00-15 0v5h5l-5 5-5-5h5V7.5a9.5 9.5 0 0119 0V17z" />
          </svg>
        );
    }
  };

  const getAlertBgColor = (type) => {
    switch (type) {
      case 'arrival': return 'bg-green-50 border-green-200';
      case 'delay': return 'bg-yellow-50 border-yellow-200';
      case 'emergency': return 'bg-red-50 border-red-200';
      case 'service': return 'bg-blue-50 border-blue-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const filteredAlerts = alerts.filter(alert => {
    const matchesReadFilter = filter === 'all' || 
      (filter === 'read' && alert.is_read) || 
      (filter === 'unread' && !alert.is_read);
    
    const matchesTypeFilter = alertType === 'all' || alert.alert_type === alertType;
    
    return matchesReadFilter && matchesTypeFilter;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">SKS Alerts</h1>
          <p className="text-gray-600 mt-1">Stay updated with bus services and notifications</p>
        </div>
        
        <div className="flex items-center space-x-2 mt-4 sm:mt-0">
          <span className="text-sm text-gray-600">
            {alerts.filter(a => !a.is_read).length} unread
          </span>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <label className="block text-sm font-medium text-gray-700">Status:</label>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Alerts</option>
              <option value="unread">Unread</option>
              <option value="read">Read</option>
            </select>
          </div>

          <div className="flex items-center space-x-4">
            <label className="block text-sm font-medium text-gray-700">Type:</label>
            <select
              value={alertType}
              onChange={(e) => setAlertType(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Types</option>
              <option value="arrival">Arrival Alerts</option>
              <option value="delay">Delay Alerts</option>
              <option value="emergency">Emergency</option>
              <option value="service">Service Updates</option>
            </select>
          </div>
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length > 0 ? (
          filteredAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`rounded-lg border p-6 transition-all hover:shadow-md ${
                getAlertBgColor(alert.alert_type)
              } ${!alert.is_read ? 'ring-2 ring-blue-200' : ''}`}
            >
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <div className={`p-2 rounded-full ${
                    alert.alert_type === 'arrival' ? 'bg-green-100' :
                    alert.alert_type === 'delay' ? 'bg-yellow-100' :
                    alert.alert_type === 'emergency' ? 'bg-red-100' :
                    'bg-blue-100'
                  }`}>
                    {getAlertIcon(alert.alert_type)}
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">
                        {alert.title}
                        {!alert.is_read && (
                          <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                            New
                          </span>
                        )}
                      </h3>
                      <p className="text-gray-700 mb-2">{alert.message}</p>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span className="capitalize font-medium text-gray-600">
                          {alert.alert_type.replace('_', ' ')}
                        </span>
                        {alert.bus_number && (
                          <span>Bus: {alert.bus_number}</span>
                        )}
                        <span>{new Date(alert.created_at).toLocaleString()}</span>
                      </div>
                    </div>
                    
                    {!alert.is_read && (
                      <button
                        onClick={() => markAsRead(alert.id)}
                        className="ml-4 text-blue-600 hover:text-blue-800 text-sm font-medium"
                      >
                        Mark as Read
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
            <div className="mx-auto h-12 w-12 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5 5-5-5h5v-5a7.5 7.5 0 00-15 0v5h5l-5 5-5-5h5V7.5a9.5 9.5 0 0119 0V17z" />
              </svg>
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">No alerts found</h3>
            <p className="text-gray-500">
              {filter === 'all' ? 'No alerts available at the moment.' :
               filter === 'unread' ? 'No unread alerts.' :
               'No read alerts.'}
            </p>
          </div>
        )}
      </div>

      {/* Alert Types Info */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Alert Types</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-green-100 rounded-lg">
              {getAlertIcon('arrival')}
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Arrival</h4>
              <p className="text-sm text-gray-600">Bus arrival notifications</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-yellow-100 rounded-lg">
              {getAlertIcon('delay')}
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Delay</h4>
              <p className="text-sm text-gray-600">Service delay alerts</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-red-100 rounded-lg">
              {getAlertIcon('emergency')}
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Emergency</h4>
              <p className="text-sm text-gray-600">Emergency notifications</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              {getAlertIcon('service')}
            </div>
            <div>
              <h4 className="font-medium text-gray-900">Service</h4>
              <p className="text-sm text-gray-600">Service updates</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AlertsPage;