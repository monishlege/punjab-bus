import requests
import sys
import json
from datetime import datetime

class PunjabBusTrackerAPITester:
    def __init__(self, base_url="https://punjab-bus-map.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_phone = "+919876543210"
        self.test_password = "test123"

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}" if not endpoint.startswith('http') else endpoint
        
        if headers is None:
            headers = {'Content-Type': 'application/json'}
        
        if self.token and 'Authorization' not in headers:
            headers['Authorization'] = f'Bearer {self.token}'

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)
            elif method == 'PATCH':
                response = requests.patch(url, json=data, headers=headers, timeout=10)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                except:
                    print(f"   Response: {response.text[:200]}...")
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                print(f"   Response: {response.text[:300]}...")

            return success, response.json() if response.headers.get('content-type', '').startswith('application/json') else response.text

        except requests.exceptions.RequestException as e:
            print(f"❌ Failed - Network Error: {str(e)}")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_health_check(self):
        """Test health check endpoint"""
        return self.run_test("Health Check", "GET", "health", 200)

    def test_cities_endpoint(self):
        """Test cities endpoint"""
        return self.run_test("Get Punjab Cities", "GET", "cities", 200)

    def test_routes_endpoint(self):
        """Test routes endpoint"""
        return self.run_test("Get Bus Routes", "GET", "routes", 200)

    def test_user_registration(self):
        """Test user registration"""
        success, response = self.run_test(
            "User Registration",
            "POST",
            "auth/register",
            200,
            data={"phone_number": self.test_phone, "password": self.test_password}
        )
        
        if success and isinstance(response, dict):
            if 'token' in response:
                self.token = response['token']
                print(f"   Token received: {self.token[:20]}...")
            if 'user' in response:
                self.user_data = response['user']
                print(f"   User ID: {self.user_data.get('id', 'N/A')}")
        
        return success, response

    def test_user_login(self):
        """Test user login"""
        success, response = self.run_test(
            "User Login",
            "POST",
            "auth/login",
            200,
            data={"phone_number": self.test_phone, "password": self.test_password}
        )
        
        if success and isinstance(response, dict):
            if 'token' in response:
                self.token = response['token']
                print(f"   Login token: {self.token[:20]}...")
            if 'user' in response:
                self.user_data = response['user']
        
        return success, response

    def test_send_otp(self):
        """Test OTP sending"""
        return self.run_test(
            "Send OTP",
            "POST",
            "otp/send",
            200,
            data={"phone_number": self.test_phone}
        )

    def test_verify_otp(self):
        """Test OTP verification with mock code"""
        return self.run_test(
            "Verify OTP (Mock)",
            "POST",
            "otp/verify",
            200,
            data={"phone_number": self.test_phone, "otp_code": "123456"}
        )

    def test_bus_simulation(self):
        """Test bus location simulation"""
        return self.run_test(
            "Simulate Bus Locations",
            "POST",
            "buses/simulate",
            200
        )

    def test_bus_locations(self):
        """Test getting bus locations"""
        return self.run_test(
            "Get Bus Locations",
            "GET",
            "buses/locations",
            200
        )

    def test_fare_calculation(self):
        """Test fare calculation"""
        # First get routes to get a route_id
        routes_success, routes_response = self.test_routes_endpoint()
        if routes_success and isinstance(routes_response, list) and len(routes_response) > 0:
            route_id = routes_response[0].get('id')
            if route_id:
                # Use query parameters instead of JSON body
                endpoint = f"fare/calculate?origin=Chandigarh&destination=Ludhiana&route_id={route_id}"
                return self.run_test(
                    "Calculate Fare",
                    "POST",
                    endpoint,
                    200
                )
        
        print("❌ Could not test fare calculation - no route ID available")
        return False, {}

    def test_alerts_system(self):
        """Test alerts system (requires authentication)"""
        if not self.token:
            print("❌ Cannot test alerts - no authentication token")
            return False, {}
        
        # Test getting alerts
        get_success, _ = self.run_test(
            "Get User Alerts",
            "GET",
            "alerts",
            200
        )
        
        # Test creating alert using query parameters
        endpoint = "alerts?alert_type=arrival&title=Test Alert&message=This is a test alert"
        create_success, create_response = self.run_test(
            "Create Alert",
            "POST",
            endpoint,
            200
        )
        
        return get_success and create_success, create_response

def main():
    print("🚌 Punjab Bus Tracker API Testing")
    print("=" * 50)
    
    tester = PunjabBusTrackerAPITester()
    
    # Test basic endpoints first
    print("\n📋 Testing Basic Endpoints...")
    tester.test_health_check()
    tester.test_cities_endpoint()
    tester.test_routes_endpoint()
    
    # Test authentication flow
    print("\n🔐 Testing Authentication...")
    reg_success, _ = tester.test_user_registration()
    
    if not reg_success:
        # Try login if registration failed (user might already exist)
        print("   Registration failed, trying login...")
        login_success, _ = tester.test_user_login()
        if not login_success:
            print("❌ Both registration and login failed, skipping authenticated tests")
    
    # Test OTP system
    print("\n📱 Testing OTP System...")
    tester.test_send_otp()
    tester.test_verify_otp()
    
    # Test bus system
    print("\n🚌 Testing Bus System...")
    tester.test_bus_simulation()
    tester.test_bus_locations()
    tester.test_fare_calculation()
    
    # Test alerts (requires authentication)
    print("\n🔔 Testing Alerts System...")
    tester.test_alerts_system()
    
    # Print final results
    print("\n" + "=" * 50)
    print(f"📊 Final Results: {tester.tests_passed}/{tester.tests_run} tests passed")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All tests passed!")
        return 0
    else:
        failed_tests = tester.tests_run - tester.tests_passed
        print(f"⚠️  {failed_tests} test(s) failed")
        return 1

if __name__ == "__main__":
    sys.exit(main())