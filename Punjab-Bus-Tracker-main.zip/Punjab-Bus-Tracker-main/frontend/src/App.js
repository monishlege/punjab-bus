import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "./App.css";
import LoginPage from "./components/LoginPage";
import Dashboard from "./components/Dashboard";
import MapView from "./components/MapView";
import AlertsPage from "./components/AlertsPage";
import RoutesPage from "./components/RoutesPage";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Auth Context
const AuthContext = React.createContext();

export const useAuth = () => {
  const context = React.useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState('dashboard');

  useEffect(() => {
    // Check for existing token
    const token = localStorage.getItem('auth_token');
    const userData = localStorage.getItem('user_data');
    
    if (token && userData) {
      setUser(JSON.parse(userData));
    }
    setLoading(false);
  }, []);

  const login = (userData, token) => {
    localStorage.setItem('auth_token', token);
    localStorage.setItem('user_data', JSON.stringify(userData));
    setUser(userData);
    toast.success('Login successful!');
  };

  const logout = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_data');
    setUser(null);
    setCurrentPage('dashboard');
    toast.info('Logged out successfully');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  const authValue = {
    user,
    login,
    logout
  };

  return (
    <AuthContext.Provider value={authValue}>
      <div className="App">
        <Router>
          <Routes>
            <Route 
              path="/login" 
              element={user ? <Navigate to="/" /> : <LoginPage />} 
            />
            <Route 
              path="/" 
              element={user ? <MainApp currentPage={currentPage} setCurrentPage={setCurrentPage} /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/map" 
              element={user ? <MainApp currentPage="map" setCurrentPage={setCurrentPage} /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/alerts" 
              element={user ? <MainApp currentPage="alerts" setCurrentPage={setCurrentPage} /> : <Navigate to="/login" />} 
            />
            <Route 
              path="/routes" 
              element={user ? <MainApp currentPage="routes" setCurrentPage={setCurrentPage} /> : <Navigate to="/login" />} 
            />
          </Routes>
        </Router>
        <ToastContainer
          position="top-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
        />
      </div>
    </AuthContext.Provider>
  );
}

const MainApp = ({ currentPage, setCurrentPage }) => {
  const { user, logout } = useAuth();

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'map':
        return <MapView />;
      case 'alerts':
        return <AlertsPage />;
      case 'routes':
        return <RoutesPage />;
      default:
        return <Dashboard setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-blue-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="bg-white p-2 rounded-full">
                  <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2v0a2 2 0 01-2-2v-2a2 2 0 00-2-2H8z" />
                  </svg>
                </div>
                <h1 className="text-xl font-bold">Punjab Bus Tracker</h1>
              </div>
            </div>
            
            {/* Navigation */}
            <nav className="hidden md:flex space-x-6">
              <button
                onClick={() => setCurrentPage('dashboard')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentPage === 'dashboard' ? 'bg-blue-700' : 'hover:bg-blue-500'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setCurrentPage('map')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentPage === 'map' ? 'bg-blue-700' : 'hover:bg-blue-500'
                }`}
              >
                Live Map
              </button>
              <button
                onClick={() => setCurrentPage('routes')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentPage === 'routes' ? 'bg-blue-700' : 'hover:bg-blue-500'
                }`}
              >
                Routes
              </button>
              <button
                onClick={() => setCurrentPage('alerts')}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentPage === 'alerts' ? 'bg-blue-700' : 'hover:bg-blue-500'
                }`}
              >
                Alerts
              </button>
            </nav>

            {/* User menu */}
            <div className="flex items-center space-x-4">
              <span className="text-sm">
                📱 {user?.phone_number}
                {user?.is_verified && (
                  <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                    Verified
                  </span>
                )}
              </span>
              <button
                onClick={logout}
                className="bg-red-500 hover:bg-red-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation */}
      <div className="md:hidden bg-blue-600 border-t border-blue-500">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-4 py-2">
            <button
              onClick={() => setCurrentPage('dashboard')}
              className={`flex-1 px-3 py-2 rounded-md text-sm font-medium text-white transition-colors ${
                currentPage === 'dashboard' ? 'bg-blue-700' : 'hover:bg-blue-500'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setCurrentPage('map')}
              className={`flex-1 px-3 py-2 rounded-md text-sm font-medium text-white transition-colors ${
                currentPage === 'map' ? 'bg-blue-700' : 'hover:bg-blue-500'
              }`}
            >
              Map
            </button>
            <button
              onClick={() => setCurrentPage('routes')}
              className={`flex-1 px-3 py-2 rounded-md text-sm font-medium text-white transition-colors ${
                currentPage === 'routes' ? 'bg-blue-700' : 'hover:bg-blue-500'
              }`}
            >
              Routes
            </button>
            <button
              onClick={() => setCurrentPage('alerts')}
              className={`flex-1 px-3 py-2 rounded-md text-sm font-medium text-white transition-colors ${
                currentPage === 'alerts' ? 'bg-blue-700' : 'hover:bg-blue-500'
              }`}
            >
              Alerts
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {renderCurrentPage()}
      </main>
    </div>
  );
};

export default App;