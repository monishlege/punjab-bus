from fastapi import FastAPI, APIRouter, HTTPException, Depends, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime, timedelta
import bcrypt
import jwt
from twilio.rest import Client
import random
import asyncio

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_HOURS = 24

# Twilio Configuration
twilio_client = Client(
    os.environ.get('TWILIO_ACCOUNT_SID'),
    os.environ.get('TWILIO_AUTH_TOKEN')
)
TWILIO_VERIFY_SERVICE = os.environ.get('TWILIO_VERIFY_SERVICE')

# Create the main app without a prefix
app = FastAPI(title="Punjab Bus Tracker API", version="1.0.0")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Security
security = HTTPBearer()

# Models
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    phone_number: str
    password_hash: str
    is_verified: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class UserCreate(BaseModel):
    phone_number: str
    password: str

class UserLogin(BaseModel):
    phone_number: str
    password: str

class OTPRequest(BaseModel):
    phone_number: str

class OTPVerify(BaseModel):
    phone_number: str
    otp_code: str

class BusRoute(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    route_name: str
    origin: str
    destination: str
    stops: List[str]
    distance_km: float
    base_fare: float
    created_at: datetime = Field(default_factory=datetime.utcnow)

class BusLocation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    bus_number: str
    route_id: str
    current_location: dict  # {"lat": float, "lng": float}
    next_stop: str
    speed_kmh: float
    passengers_count: int
    last_updated: datetime = Field(default_factory=datetime.utcnow)

class Alert(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    alert_type: str  # arrival, delay, emergency, service
    title: str
    message: str
    route_id: Optional[str] = None
    bus_number: Optional[str] = None
    is_read: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)

class FareCalculation(BaseModel):
    origin: str
    destination: str
    route_id: str
    distance_km: float
    base_fare: float
    calculated_fare: float

# Punjab Cities and Routes Data
PUNJAB_CITIES = [
    "Chandigarh", "Ludhiana", "Amritsar", "Jalandhar", "Patiala",
    "Bathinda", "Mohali", "Firozpur", "Hoshiarpur", "Pathankot",
    "Moga", "Abohar", "Malerkotla", "Khanna", "Phagwara"
]

# Mock Bus Routes
BUS_ROUTES_DATA = [
    {
        "route_name": "CHD-LDH Express",
        "origin": "Chandigarh",
        "destination": "Ludhiana",
        "stops": ["Chandigarh", "Mohali", "Kharar", "Kurali", "Morinda", "Samrala", "Ludhiana"],
        "distance_km": 110.0,
        "base_fare": 120.0
    },
    {
        "route_name": "ASR-JLR Route",
        "origin": "Amritsar",
        "destination": "Jalandhar",
        "stops": ["Amritsar", "Tarn Taran", "Patti", "Kapurthala", "Jalandhar"],
        "distance_km": 85.0,
        "base_fare": 95.0
    },
    {
        "route_name": "PTL-BTI Line",
        "origin": "Patiala",
        "destination": "Bathinda",
        "stops": ["Patiala", "Sangrur", "Barnala", "Mansa", "Bathinda"],
        "distance_km": 140.0,
        "base_fare": 150.0
    },
    {
        "route_name": "CHD-ASR Highway",
        "origin": "Chandigarh",
        "destination": "Amritsar",
        "stops": ["Chandigarh", "Mohali", "Kharar", "Ludhiana", "Phagwara", "Jalandhar", "Amritsar"],
        "distance_km": 230.0,
        "base_fare": 280.0
    }
]

# Helper Functions
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_jwt_token(user_id: str, phone_number: str) -> str:
    payload = {
        'user_id': user_id,
        'phone_number': phone_number,
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_jwt_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    payload = verify_jwt_token(credentials.credentials)
    user = await db.users.find_one({"id": payload["user_id"]})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return User(**user)

# Initialize data
@api_router.on_event("startup")
async def initialize_data():
    # Create indexes
    await db.users.create_index("phone_number", unique=True)
    await db.bus_routes.create_index("route_name", unique=True)
    await db.bus_locations.create_index("bus_number")
    
    # Insert initial bus routes if not exists
    for route_data in BUS_ROUTES_DATA:
        existing = await db.bus_routes.find_one({"route_name": route_data["route_name"]})
        if not existing:
            route = BusRoute(**route_data)
            await db.bus_routes.insert_one(route.dict())

# Authentication Routes
@api_router.post("/auth/register")
async def register_user(user_data: UserCreate):
    # Check if user already exists
    existing_user = await db.users.find_one({"phone_number": user_data.phone_number})
    if existing_user:
        raise HTTPException(status_code=400, detail="Phone number already registered")
    
    # Create new user
    hashed_password = hash_password(user_data.password)
    user = User(
        phone_number=user_data.phone_number,
        password_hash=hashed_password
    )
    
    await db.users.insert_one(user.dict())
    
    # Generate JWT token
    token = create_jwt_token(user.id, user.phone_number)
    
    return {
        "message": "User registered successfully",
        "token": token,
        "user": {
            "id": user.id,
            "phone_number": user.phone_number,
            "is_verified": user.is_verified
        }
    }

@api_router.post("/auth/login")
async def login_user(login_data: UserLogin):
    # Find user
    user_doc = await db.users.find_one({"phone_number": login_data.phone_number})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    user = User(**user_doc)
    
    # Verify password
    if not verify_password(login_data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Generate JWT token
    token = create_jwt_token(user.id, user.phone_number)
    
    return {
        "message": "Login successful",
        "token": token,
        "user": {
            "id": user.id,
            "phone_number": user.phone_number,
            "is_verified": user.is_verified
        }
    }

# OTP Routes
@api_router.post("/otp/send")
async def send_otp(otp_request: OTPRequest):
    try:
        if TWILIO_VERIFY_SERVICE:
            verification = twilio_client.verify.services(TWILIO_VERIFY_SERVICE) \
                .verifications.create(to=otp_request.phone_number, channel="sms")
            return {"message": "OTP sent successfully", "status": verification.status}
        else:
            # For development - mock OTP (always 123456)
            return {"message": "OTP sent successfully (Mock: 123456)", "status": "pending"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to send OTP: {str(e)}")

@api_router.post("/otp/verify")
async def verify_otp(otp_data: OTPVerify):
    try:
        if TWILIO_VERIFY_SERVICE:
            check = twilio_client.verify.services(TWILIO_VERIFY_SERVICE) \
                .verification_checks.create(to=otp_data.phone_number, code=otp_data.otp_code)
            is_valid = check.status == "approved"
        else:
            # For development - accept 123456 as valid OTP
            is_valid = otp_data.otp_code == "123456"
        
        if is_valid:
            # Mark user as verified
            await db.users.update_one(
                {"phone_number": otp_data.phone_number},
                {"$set": {"is_verified": True, "updated_at": datetime.utcnow()}}
            )
        
        return {"valid": is_valid, "message": "OTP verified" if is_valid else "Invalid OTP"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to verify OTP: {str(e)}")

# Bus Routes
@api_router.get("/routes", response_model=List[BusRoute])
async def get_bus_routes():
    routes = await db.bus_routes.find().to_list(100)
    return [BusRoute(**route) for route in routes]

@api_router.get("/routes/{route_id}", response_model=BusRoute)
async def get_route_by_id(route_id: str):
    route = await db.bus_routes.find_one({"id": route_id})
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")
    return BusRoute(**route)

# Bus Locations (Real-time simulation)
@api_router.get("/buses/locations", response_model=List[BusLocation])
async def get_bus_locations():
    locations = await db.bus_locations.find().to_list(100)
    return [BusLocation(**location) for location in locations]

@api_router.get("/buses/{route_id}/locations", response_model=List[BusLocation])
async def get_buses_by_route(route_id: str):
    locations = await db.bus_locations.find({"route_id": route_id}).to_list(100)
    return [BusLocation(**location) for location in locations]

# Simulate bus movement
@api_router.post("/buses/simulate")
async def simulate_bus_locations():
    routes = await db.bus_routes.find().to_list(100)
    
    # Clear existing locations
    await db.bus_locations.delete_many({})
    
    for route in routes:
        # Create 2-3 buses per route
        for i in range(random.randint(2, 3)):
            bus_number = f"PB-{random.randint(10, 99)}-{random.randint(1000, 9999)}"
            
            # Random location along route (simplified)
            lat_start = 30.7333 + random.uniform(-0.5, 0.5)  # Punjab latitude range
            lng_start = 76.7794 + random.uniform(-0.5, 0.5)  # Punjab longitude range
            
            bus_location = BusLocation(
                bus_number=bus_number,
                route_id=route["id"],
                current_location={"lat": lat_start, "lng": lng_start},
                next_stop=random.choice(route["stops"]),
                speed_kmh=random.randint(40, 80),
                passengers_count=random.randint(10, 50)
            )
            
            await db.bus_locations.insert_one(bus_location.dict())
    
    return {"message": "Bus locations simulated successfully"}

# Fare calculation
@api_router.post("/fare/calculate", response_model=FareCalculation)
async def calculate_fare(origin: str, destination: str, route_id: str):
    route = await db.bus_routes.find_one({"id": route_id})
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")
    
    # Simple fare calculation based on distance
    base_fare = route["base_fare"]
    distance = route["distance_km"]
    
    # Calculate fare (simplified - you can make this more complex)
    calculated_fare = base_fare * 1.0  # Base fare for full route
    
    return FareCalculation(
        origin=origin,
        destination=destination,
        route_id=route_id,
        distance_km=distance,
        base_fare=base_fare,
        calculated_fare=calculated_fare
    )

# Alerts system
@api_router.get("/alerts", response_model=List[Alert])
async def get_user_alerts(current_user: User = Depends(get_current_user)):
    alerts = await db.alerts.find({"user_id": current_user.id}).sort("created_at", -1).to_list(50)
    return [Alert(**alert) for alert in alerts]

@api_router.post("/alerts")
async def create_alert(
    alert_type: str,
    title: str,
    message: str,
    route_id: Optional[str] = None,
    bus_number: Optional[str] = None,
    current_user: User = Depends(get_current_user)
):
    alert = Alert(
        user_id=current_user.id,
        alert_type=alert_type,
        title=title,
        message=message,
        route_id=route_id,
        bus_number=bus_number
    )
    
    await db.alerts.insert_one(alert.dict())
    return {"message": "Alert created successfully", "alert_id": alert.id}

@api_router.patch("/alerts/{alert_id}/read")
async def mark_alert_read(alert_id: str, current_user: User = Depends(get_current_user)):
    result = await db.alerts.update_one(
        {"id": alert_id, "user_id": current_user.id},
        {"$set": {"is_read": True}}
    )
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Alert not found")
    return {"message": "Alert marked as read"}

# Cities endpoint
@api_router.get("/cities")
async def get_punjab_cities():
    return {"cities": PUNJAB_CITIES}

# Test endpoints
@api_router.get("/")
async def root():
    return {"message": "Punjab Bus Tracker API v1.0"}

@api_router.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow()}

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()