import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const RoutesPage = () => {
  const [routes, setRoutes] = useState([]);
  const [cities, setCities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrigin, setSelectedOrigin] = useState('');
  const [selectedDestination, setSelectedDestination] = useState('');
  const [fareCalculations, setFareCalculations] = useState({});

  useEffect(() => {
    fetchRoutesAndCities();
  }, []);

  const fetchRoutesAndCities = async () => {
    try {
      const [routesResponse, citiesResponse] = await Promise.all([
        axios.get(`${API}/routes`),
        axios.get(`${API}/cities`)
      ]);
      
      setRoutes(routesResponse.data);
      setCities(citiesResponse.data.cities);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load routes and cities');
    } finally {
      setLoading(false);
    }
  };

  const calculateFare = async (routeId, origin, destination) => {
    try {
      const response = await axios.post(`${API}/fare/calculate?origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&route_id=${routeId}`);
      
      setFareCalculations(prev => ({
        ...prev,
        [routeId]: response.data
      }));
    } catch (error) {
      console.error('Error calculating fare:', error);
      toast.error('Failed to calculate fare');
    }
  };

  const getFilteredRoutes = () => {
    if (!selectedOrigin && !selectedDestination) {
      return routes;
    }
    
    return routes.filter(route => {
      const matchesOrigin = !selectedOrigin || 
        route.origin.toLowerCase().includes(selectedOrigin.toLowerCase()) ||
        route.stops.some(stop => stop.toLowerCase().includes(selectedOrigin.toLowerCase()));
      
      const matchesDestination = !selectedDestination || 
        route.destination.toLowerCase().includes(selectedDestination.toLowerCase()) ||
        route.stops.some(stop => stop.toLowerCase().includes(selectedDestination.toLowerCase()));
      
      return matchesOrigin && matchesDestination;
    });
  };

  const getDurationEstimate = (distance) => {
    const averageSpeed = 50; // km/h
    const hours = distance / averageSpeed;
    const hoursInt = Math.floor(hours);
    const minutes = Math.round((hours - hoursInt) * 60);
    
    if (hoursInt > 0) {
      return `${hoursInt}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const filteredRoutes = getFilteredRoutes();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Bus Routes</h1>
          <p className="text-gray-600 mt-1">Explore all available routes across Punjab</p>
        </div>
        
        <div className="mt-4 sm:mt-0 bg-blue-50 border border-blue-200 rounded-lg px-4 py-2">
          <p className="text-sm text-blue-800">
            <strong>{routes.length}</strong> routes available
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Find Your Route</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              From (Origin)
            </label>
            <select
              value={selectedOrigin}
              onChange={(e) => setSelectedOrigin(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select origin city</option>
              {cities.map((city) => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              To (Destination)
            </label>
            <select
              value={selectedDestination}
              onChange={(e) => setSelectedDestination(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select destination city</option>
              {cities.map((city) => (
                <option key={city} value={city}>{city}</option>
              ))}
            </select>
          </div>
        </div>
        
        {(selectedOrigin || selectedDestination) && (
          <div className="mt-4 flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Showing {filteredRoutes.length} route(s) for your search
            </p>
            <button
              onClick={() => {
                setSelectedOrigin('');
                setSelectedDestination('');
              }}
              className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>

      {/* Routes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredRoutes.length > 0 ? (
          filteredRoutes.map((route) => (
            <div key={route.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              {/* Route Header */}
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6">
                <h3 className="text-xl font-bold mb-2">{route.route_name}</h3>
                <div className="flex items-center space-x-2">
                  <span className="text-blue-100">{route.origin}</span>
                  <svg className="w-4 h-4 text-blue-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                  <span className="text-blue-100">{route.destination}</span>
                </div>
              </div>

              {/* Route Details */}
              <div className="p-6">
                {/* Stats */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">₹{route.base_fare}</div>
                    <div className="text-sm text-gray-600">Base Fare</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{route.distance_km} km</div>
                    <div className="text-sm text-gray-600">Distance</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{getDurationEstimate(route.distance_km)}</div>
                    <div className="text-sm text-gray-600">Duration</div>
                  </div>
                </div>

                {/* Stops */}
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Route Stops</h4>
                  <div className="flex flex-wrap gap-2">
                    {route.stops.map((stop, index) => (
                      <span
                        key={index}
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          index === 0 || index === route.stops.length - 1
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {index === 0 && '🚀 '}
                        {index === route.stops.length - 1 && '🏁 '}
                        {stop}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Fare Calculator */}
                <div className="border-t border-gray-200 pt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Calculate fare for this route:</span>
                    <button
                      onClick={() => calculateFare(route.id, route.origin, route.destination)}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                    >
                      Calculate Fare
                    </button>
                  </div>
                  
                  {fareCalculations[route.id] && (
                    <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-md">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-green-800">
                          {fareCalculations[route.id].origin} → {fareCalculations[route.id].destination}
                        </span>
                        <span className="font-bold text-green-800">
                          ₹{fareCalculations[route.id].calculated_fare}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-2">
            <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
              <div className="mx-auto h-12 w-12 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-1">No routes found</h3>
              <p className="text-gray-500">
                Try adjusting your search criteria or clear the filters.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Cities Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Punjab Cities Covered</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
          {cities.map((city) => (
            <div
              key={city}
              className="bg-gray-50 rounded-lg p-3 text-center hover:bg-gray-100 transition-colors cursor-pointer"
              onClick={() => {
                if (!selectedOrigin) {
                  setSelectedOrigin(city);
                } else if (!selectedDestination && selectedOrigin !== city) {
                  setSelectedDestination(city);
                }
              }}
            >
              <div className="text-sm font-medium text-gray-900">{city}</div>
              <div className="text-xs text-gray-600">
                {routes.filter(r => 
                  r.origin === city || r.destination === city || r.stops.includes(city)
                ).length} routes
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RoutesPage;