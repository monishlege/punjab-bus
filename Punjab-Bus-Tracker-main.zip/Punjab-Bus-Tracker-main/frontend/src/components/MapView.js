import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { toast } from 'react-toastify';
import axios from 'axios';
import 'leaflet/dist/leaflet.css';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Fix Leaflet default markers
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom bus icon
const busIcon = new L.Icon({
  iconUrl: 'data:image/svg+xml;base64,' + btoa(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#3B82F6" width="32" height="32">
      <path d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2v0a2 2 0 01-2-2v-2a2 2 0 00-2-2H8z"/>
    </svg>
  `),
  iconSize: [32, 32],
  iconAnchor: [16, 32],
  popupAnchor: [0, -32],
});

const MapView = () => {
  const [busLocations, setBusLocations] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [selectedRoute, setSelectedRoute] = useState('');
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);

  // Punjab center coordinates
  const punjabCenter = [30.7333, 76.7794];

  useEffect(() => {
    fetchInitialData();
  }, []);

  useEffect(() => {
    let interval;
    if (autoRefresh) {
      interval = setInterval(() => {
        fetchBusLocations();
      }, 10000); // Refresh every 10 seconds
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [autoRefresh, selectedRoute]);

  const fetchInitialData = async () => {
    try {
      // Fetch routes
      const routesResponse = await axios.get(`${API}/routes`);
      setRoutes(routesResponse.data);

      // Simulate buses if none exist
      await axios.post(`${API}/buses/simulate`);
      
      // Fetch bus locations
      await fetchBusLocations();
    } catch (error) {
      console.error('Error fetching initial data:', error);
      toast.error('Failed to load map data');
    } finally {
      setLoading(false);
    }
  };

  const fetchBusLocations = async () => {
    try {
      const endpoint = selectedRoute 
        ? `/buses/${selectedRoute}/locations`
        : '/buses/locations';
      
      const response = await axios.get(`${API}${endpoint}`);
      setBusLocations(response.data);
    } catch (error) {
      console.error('Error fetching bus locations:', error);
    }
  };

  const simulateMovement = async () => {
    try {
      await axios.post(`${API}/buses/simulate`);
      await fetchBusLocations();
      toast.success('Bus locations updated!');
    } catch (error) {
      toast.error('Failed to update bus locations');
    }
  };

  const getRoutePolyline = (route) => {
    // Simplified route path based on stops
    const positions = route.stops.map((stop, index) => {
      const baseLatLng = [30.7333 + (index * 0.1), 76.7794 + (index * 0.1)];
      return baseLatLng;
    });
    return positions;
  };

  const getBusStatusColor = (speed) => {
    if (speed === 0) return '#EF4444'; // Red for stopped
    if (speed < 30) return '#F59E0B'; // Yellow for slow
    return '#10B981'; // Green for normal
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading map...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Live Bus Map</h1>
          <p className="text-gray-600 mt-1">Real-time bus tracking across Punjab</p>
        </div>
        
        <div className="flex items-center space-x-4 mt-4 sm:mt-0">
          <button
            onClick={simulateMovement}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
          >
            Update Locations
          </button>
          
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`px-4 py-2 rounded-lg transition-colors ${
              autoRefresh 
                ? 'bg-green-600 hover:bg-green-700 text-white' 
                : 'bg-gray-300 hover:bg-gray-400 text-gray-700'
            }`}
          >
            Auto Refresh {autoRefresh ? 'ON' : 'OFF'}
          </button>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <label className="block text-sm font-medium text-gray-700">
              Filter by Route:
            </label>
            <select
              value={selectedRoute}
              onChange={(e) => setSelectedRoute(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Routes</option>
              {routes.map((route) => (
                <option key={route.id} value={route.id}>
                  {route.route_name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-6 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span>Moving</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <span>Slow</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <span>Stopped</span>
            </div>
          </div>
        </div>
      </div>

      {/* Map */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <MapContainer
          center={punjabCenter}
          zoom={9}
          scrollWheelZoom={true}
          style={{ height: '70vh', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {/* Route lines */}
          {routes
            .filter(route => !selectedRoute || route.id === selectedRoute)
            .map((route) => (
              <Polyline
                key={`route-${route.id}`}
                positions={getRoutePolyline(route)}
                color="#8B5CF6"
                weight={3}
                opacity={0.7}
                dashArray="10, 10"
              />
            ))}

          {/* Bus markers */}
          {busLocations.map((bus) => {
            const route = routes.find(r => r.id === bus.route_id);
            return (
              <Marker
                key={bus.id}
                position={[bus.current_location.lat, bus.current_location.lng]}
                icon={busIcon}
              >
                <Popup>
                  <div className="p-2">
                    <h3 className="font-bold text-gray-900">{bus.bus_number}</h3>
                    <p className="text-sm text-gray-600">
                      Route: {route?.route_name || 'Unknown'}
                    </p>
                    <p className="text-sm text-gray-600">
                      Next Stop: {bus.next_stop}
                    </p>
                    <div className="mt-2 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">Speed:</span>
                        <span 
                          className="text-xs font-medium px-2 py-1 rounded"
                          style={{ 
                            backgroundColor: getBusStatusColor(bus.speed_kmh) + '20',
                            color: getBusStatusColor(bus.speed_kmh)
                          }}
                        >
                          {bus.speed_kmh} km/h
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">Passengers:</span>
                        <span className="text-xs font-medium">{bus.passengers_count}</span>
                      </div>
                      <div className="text-xs text-gray-500">
                        Updated: {new Date(bus.last_updated).toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      </div>

      {/* Bus List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Active Buses</h3>
        </div>
        <div className="p-6">
          {busLocations.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {busLocations.map((bus) => {
                const route = routes.find(r => r.id === bus.route_id);
                return (
                  <div key={bus.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-gray-900">{bus.bus_number}</h4>
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: getBusStatusColor(bus.speed_kmh) }}
                      ></div>
                    </div>
                    <p className="text-sm text-gray-600 mb-1">
                      {route?.route_name || 'Unknown Route'}
                    </p>
                    <p className="text-sm text-gray-600 mb-2">
                      Next: {bus.next_stop}
                    </p>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{bus.speed_kmh} km/h</span>
                      <span>{bus.passengers_count} passengers</span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="mx-auto h-12 w-12 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2v0a2 2 0 01-2-2v-2a2 2 0 00-2-2H8z" />
                </svg>
              </div>
              <p className="text-gray-500">No buses currently active</p>
              <button
                onClick={simulateMovement}
                className="mt-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
              >
                Simulate Bus Movement
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MapView;